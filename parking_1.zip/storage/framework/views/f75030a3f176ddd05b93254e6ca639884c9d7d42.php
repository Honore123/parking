<?php $__env->startSection('content'); ?>
    <div class="row mt-3">
        <div class="col-md-12">
            <?php echo $__env->make('layouts.partials.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="row justify-content-between" id="parkingMenu">

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function () {
            setInterval(function () {

                $('#parkingMenu').load('/parking');
            }, 1000)
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H01\OneDrive\Documents\Jessy\parking\resources\views/dashboard/index.blade.php ENDPATH**/ ?>