<div class="col-md-12 my-4">
    <h3>Available space: <span class="badge bg-success"><?php echo e($parkings->where('availability',1)->count() + $parkingSeconds->where('availability',1)->count()); ?></span>
    </h3>
</div>
<div class="col-md-12 mb-4 border-bottom">
    <h5>Parking space 1</h5>
</div>
<?php $__empty_1 = true; $__currentLoopData = $parkings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-3 card <?php echo e($parking->availability == 1 ? 'border-success': ($parking->availability == 2 ? 'border-info' :'border-danger')); ?> mx-md-2 mb-3">
        <div class="card-body">
            <h5 class="card-title">Slot <?php echo e($loop->iteration); ?>:
                <?php if($parking->availability == 1): ?>
                    <span class="badge bg-success">Available</span>
                <?php elseif($parking->availability == 2): ?>
                    <span class="badge bg-info">Booked</span>
                <?php else: ?>
                    <span class="badge bg-danger">Unavailable</span>
                <?php endif; ?>
            </h5>
            <p>
                <i class="fas fa-car <?php echo e($parking->availability != 1 ? 'text-black': 'text-white'); ?>" style="font-size: 4em"></i></p>
            <?php if(!is_null($user) && $user->parking_lot_id == $parking->id): ?>
                <?php if($door->state == 0): ?>
                <form action="<?php echo e(route('booking.door',1)); ?>" method="post" class="mb-3">
                    <?php echo csrf_field(); ?>
                    <button href="#" class="btn btn-primary text-light rounded-0 w-100">Open Gate</button>
                </form>
                <?php else: ?>
                    <div class="alert alert-primary d-flex align-items-center" role="alert">
                        <i class="fas fa-info-circle me-2" style="font-size: 1.5em"></i>
                        <div>
                            Press the button at the gate
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <?php if($parking->availability == 1): ?>
                <form action="<?php echo e(route('booking.store',$parking->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button href="#" class="btn btn-success rounded-0 w-100">Book</button>
                </form>

                <?php elseif($parking->availability == 2 && !is_null($user) ): ?>
                <form action="<?php echo e(route('booking.delete',$parking->id)); ?>" method="post">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button href="#" class="btn btn-danger text-light rounded-0 w-100">Cancel</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-md-12">
        <p class="display-6 text-center">There is no parking space yet :(</p>
    </div>
<?php endif; ?>
<div class="col-md-12 mt-5 mb-4 border-bottom">
    <h5>Parking space 2</h5>
</div>
<?php $__empty_1 = true; $__currentLoopData = $parkingSeconds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-3 card <?php echo e($parking->availability == 1 ? 'border-success': ($parking->availability == 2 ? 'border-info' :'border-danger')); ?> mx-md-2 mb-3">
        <div class="card-body">
            <h5 class="card-title">Slot <?php echo e($loop->iteration); ?>:
                <?php if($parking->availability == 1): ?>
                    <span class="badge bg-success">Available</span>
                <?php elseif($parking->availability == 2): ?>
                    <span class="badge bg-info">Booked</span>
                <?php else: ?>
                    <span class="badge bg-danger">Unavailable</span>
                <?php endif; ?>
            </h5>
            <p>
                <i class="fas fa-car <?php echo e($parking->availability != 1 ? 'text-black': 'text-white'); ?>" style="font-size: 4em"></i></p>
            <?php if(!is_null($user) && $user->parking_lot_id == $parking->id): ?>
                <?php if($door->state == 0): ?>
                    <form action="<?php echo e(route('booking.door',1)); ?>" method="post" class="mb-3">
                        <?php echo csrf_field(); ?>
                        <button href="#" class="btn btn-primary text-light rounded-0 w-100">Open Gate</button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-primary d-flex align-items-center" role="alert">
                        <i class="fas fa-info-circle me-2" style="font-size: 1.5em"></i>
                        <div>
                            Press the button at the gate
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <?php if($parking->availability == 1): ?>
                <form action="<?php echo e(route('booking.store',$parking->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button href="#" class="btn btn-success rounded-0 w-100">Book</button>
                </form>

            <?php elseif($parking->availability == 2 && !is_null($user) ): ?>
                <form action="<?php echo e(route('booking.delete',$parking->id)); ?>" method="post">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button href="#" class="btn btn-danger text-light rounded-0 w-100">Cancel</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-md-12">
        <p class="display-6 text-center">There is no parking space yet :(</p>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\H01\OneDrive\Documents\Jessy\parking\resources\views/dashboard/partials/parking.blade.php ENDPATH**/ ?>