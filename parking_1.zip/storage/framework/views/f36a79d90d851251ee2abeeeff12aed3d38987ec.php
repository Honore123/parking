<div class="col-md-12">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <h5>
                <i class="icon fas fa-ban"></i>
                Error!
            </h5>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul>
                    <li><?php echo e($error); ?></li>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <h5>
                <i class="icon fas fa-check"></i>
                Success
            </h5>
            <?php echo session('success'); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <h5>
                <i class="icon fas fa-ban"></i>
                Error!
            </h5>
            <?php echo session('error'); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\H01\OneDrive\Documents\Jessy\parking\resources\views/layouts/partials/notification.blade.php ENDPATH**/ ?>